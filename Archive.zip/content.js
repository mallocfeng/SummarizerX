// 注入到页面：抓取原始文本 + 本地 Markdown；并提供探针
(function () {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "PING_EXTRACTOR") {
      sendResponse({ ok: true });
      return true;
    }
    if (msg?.type === "GET_PAGE_RAW") {
      try {
        const fn = window.__AI_READ_EXTRACT__;
        const { title, text, markdown } = fn ? fn() : {
          title: document.title || "",
          text: document.body?.innerText || "",
          markdown: `# ${document.title || ""}\n\n${(document.body?.innerText || "").trim()}`
        };
        const pageLang = (document.documentElement.getAttribute("lang") || navigator.language || "").toString();
        sendResponse({ ok: true, payload: { title, text, markdown, url: location.href, pageLang } });
      } catch (e) {
        sendResponse({ ok: false, error: e?.message || String(e) });
      }
      return true;
    }
  });
})();