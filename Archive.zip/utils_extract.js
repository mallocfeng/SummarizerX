// 本地快速正文抽取 + 轻量 Markdown 生成（不调用 AI）
(function () {
  function isVisible(el) {
    if (!(el instanceof Element)) return false;
    const style = window.getComputedStyle(el);
    return style && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }

  function scoreNode(node) {
    if (!(node instanceof Element)) return -1000;
    const bad = /nav|aside|footer|header|form|menu|banner|complementary|advert|ads|promo|recommend|subscribe|signup|comment|related/i;
    const good = /article|main|content|post|entry|markdown|doc|read|story|body|page/i;
    let score = 0;
    const idClass = `${node.id || ""} ${node.className || ""}`;
    if (good.test(idClass)) score += 20;
    if (bad.test(idClass)) score -= 20;
    // 文本长度加权
    const len = (node.innerText || "").length;
    score += Math.min(20, len / 600);
    // 标签偏好
    const tag = node.tagName;
    if (["ARTICLE", "MAIN"].includes(tag)) score += 5;
    return score;
  }

  function pickRoot() {
    // 先看明显的候选
    const cands = Array.from(document.querySelectorAll("article, main, [role=main]"));
    if (cands.length) return cands.sort((a,b)=>scoreNode(b)-scoreNode(a))[0];
    // 否则在 body 下找得分最高的块级容器
    const blocks = Array.from(document.body.querySelectorAll("div, section, article, main"));
    blocks.sort((a,b)=>scoreNode(b)-scoreNode(a));
    return blocks[0] || document.body;
  }

  function extractBlocks(root) {
    const blacklist = new Set(["SCRIPT","STYLE","NOSCRIPT","IFRAME","SVG","CANVAS","NAV","ASIDE","FOOTER","HEADER","FORM"]);
    const out = [];

    function push(kind, text) {
      const t = (text || "").trim().replace(/\s+\n/g, "\n").replace(/\n{3,}/g, "\n\n");
      if (t) out.push({ kind, text: t });
    }

    function walk(node) {
      if (!(node instanceof Element)) return;
      if (!isVisible(node)) return;
      if (blacklist.has(node.tagName)) return;

      const tag = node.tagName;
      // 列表
      if (tag === "UL" || tag === "OL") {
        const items = Array.from(node.children).map(li => (li.innerText || "").trim()).filter(Boolean);
        if (items.length) push(tag, items.join("\n"));
      }
      // 标题
      else if (/^H[1-4]$/.test(tag)) {
        push(tag, (node.innerText || "").trim());
      }
      // 段落/区块
      else if (["P","DIV","SECTION","ARTICLE"].includes(tag)) {
        // 只采样文本量较大的块，避免抓到导航按钮
        const txt = (node.innerText || "").trim();
        if (txt && txt.replace(/\s/g,"").length >= 80) push("P", txt);
      }

      // 深入遍历
      for (const el of node.children) walk(el);
      if (node.shadowRoot) for (const el of node.shadowRoot.children) walk(el);
    }

    walk(root);
    return out;
  }

  function toMarkdown(blocks) {
    const lines = [];
    let prev = "";

    for (const b of blocks) {
      if (b.kind === "UL") {
        const items = b.text.split("\n").map(s => s.trim()).filter(Boolean);
        if (items.length) {
          lines.push(items.map(i => `- ${i}`).join("\n"));
          lines.push(""); // 空行
        }
      } else if (b.kind === "OL") {
        const items = b.text.split("\n").map(s => s.trim()).filter(Boolean);
        if (items.length) {
          lines.push(items.map((i,idx) => `${idx+1}. ${i}`).join("\n"));
          lines.push("");
        }
      } else if (/^H[1-4]$/.test(b.kind)) {
        const lvl = Number(b.kind.replace("H",""));
        lines.push(`${"#".repeat(Math.min(4, lvl))} ${b.text}`);
        lines.push("");
      } else {
        // 合并重复段落
        const t = b.text.replace(/\s+/g, " ");
        if (t && t !== prev) {
          lines.push(t);
          lines.push("");
          prev = t;
        }
      }
    }
    const md = lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
    return md;
  }

  window.__AI_READ_EXTRACT__ = function () {
    try {
      const root = pickRoot();
      const title = document.title || (document.querySelector("h1")?.innerText || "");
      const blocks = extractBlocks(root);
      // 在最前面附上标题
      if (title) blocks.unshift({ kind: "H1", text: title });
      const markdown = toMarkdown(blocks);
      const text = blocks.map(b => b.text).join("\n\n");
      return { title, text, markdown };
    } catch (e) {
      console.error("extract error", e);
      const title = document.title || "";
      const text = document.body?.innerText || "";
      const markdown = `# ${title}\n\n${(text || "").trim()}`;
      return { title, text, markdown };
    }
  };
})();