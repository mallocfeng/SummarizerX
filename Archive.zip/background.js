// 后台：读取配置，按开关选择“本地快速提取”或“AI 清洗”，然后做摘要
const DEFAULT_CONFIG = {
  baseURL: "https://api.openai.com/v1",
  model_extract: "gpt-4o-mini",
  model_summarize: "gpt-4o-mini",
  lang: "",            // 为空/auto 表示自动匹配
  extract_mode: "fast" // fast=本地快速，ai=调用AI清洗
};

async function getSettings() {
  const d = await chrome.storage.sync.get(["apiKey","baseURL","model_extract","model_summarize","lang","extract_mode"]);
  return {
    apiKey: d.apiKey || "",
    baseURL: d.baseURL || DEFAULT_CONFIG.baseURL,
    model_extract: d.model_extract || DEFAULT_CONFIG.model_extract,
    model_summarize: d.model_summarize || DEFAULT_CONFIG.model_summarize,
    lang: (d.lang === undefined ? "" : d.lang),
    extract_mode: d.extract_mode || DEFAULT_CONFIG.extract_mode
  };
}

chrome.action.onClicked.addListener(async (tab) => {
  if (chrome.sidePanel) {
    await chrome.sidePanel.open({ tabId: tab.id });
    await chrome.sidePanel.setOptions({ tabId: tab.id, path: "sidepanel.html", enabled: true });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "AI_SUMMARIZE_REQUEST") {
    handleSummarize(message.payload)
      .then((res) => sendResponse({ ok: true, data: res }))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }
  if (message?.type === "GET_MODEL_INFO") {
    getSettings().then((cfg) => {
      sendResponse({
        ok: true,
        data: {
          baseURL: cfg.baseURL,
          model_extract: cfg.model_extract,
          model_summarize: cfg.model_summarize,
          lang: cfg.lang || "auto",
          extract_mode: cfg.extract_mode
        }
      });
    });
    return true;
  }
});

function detectLang(preferred, pageLang, rawText) {
  if (preferred && preferred !== "auto" && preferred !== "") return preferred;
  const langTag = (pageLang || "").toLowerCase();
  if (langTag.startsWith("zh")) return "zh";
  if (/[\u4e00-\u9fff]/.test(rawText || "")) return "zh";
  return "en";
}

async function chatCompletion({ baseURL, apiKey, model, system, prompt, temperature = 0.2 }) {
  const url = `${baseURL.replace(/\/$/, "")}/chat/completions`;
  const body = {
    model, temperature,
    messages: [system ? { role: "system", content: system } : null, { role: "user", content: prompt }].filter(Boolean)
  };
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type":"application/json", "Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  const json = await res.json();
  return json.choices?.[0]?.message?.content || "";
}

async function handleSummarize({ url, rawText, title, pageLang, markdown }) {
  const { apiKey, baseURL, model_extract, model_summarize, lang, extract_mode } = await getSettings();
  if (!apiKey) throw new Error("请先到设置页保存 API Key（点击齿轮/选项进入）。");

  const useLang = detectLang(lang === "" ? "auto" : lang, pageLang, rawText);
  const sysLangWord = useLang === "zh" ? "Chinese" : "English";

  // 1) 清洗/正文：根据 extract_mode 选择
  let cleanedMarkdown = "";
  if (extract_mode === "fast" && markdown) {
    cleanedMarkdown = markdown.slice(0, 20000);
  } else {
    const TEXT_LIMIT = 20000;
    const clipped = (rawText || "").slice(0, TEXT_LIMIT);
    const system1 = `You are an article cleaner. Output clean Markdown in ${sysLangWord}. Remove navigation, ads, boilerplate and duplicates. Keep the main body, headings and key lists.`;
    const prompt1 = `Title: ${title || "(none)"}\nURL: ${url}\n\nRaw content (may be noisy). Please return ONLY the cleaned Markdown in ${sysLangWord}:\n\n${clipped}`;
    cleanedMarkdown = await chatCompletion({ baseURL, apiKey, model: model_extract, system: system1, prompt: prompt1 });
  }

  // 2) 摘要（同语言）
  const system2 = `You are a distillation assistant. Write the summary in ${sysLangWord}, concise and faithful.`;
  const prompt2 = `Based on the cleaned Markdown below, produce:\n1) 3–5 bullets of key takeaways\n2) One-sentence conclusion or recommendation\n3) 3–6 keywords\n\nCleaned Markdown:\n${cleanedMarkdown}`;
  const summary = await chatCompletion({ baseURL, apiKey, model: model_summarize, system: system2, prompt: prompt2 });

  return { cleanedMarkdown, summary, meta: { baseURL, model_extract, model_summarize, lang: useLang, extract_mode } };
}