// 侧栏：主界面仅展示摘要 & 清洗正文；设置在独立 options 页面；按“当前标签页 URL”独立缓存 + 空态渲染
const $ = (id) => document.getElementById(id);
const onReady = new Promise((r) => (document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", r) : r()));

// ---- Storage shim: 兼容旧版 Chrome（无 session 时回退到 local）----
const S = (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;

// ------- 轻量 Markdown 渲染 -------
function escapeHtml(str) { return (str || "").replace(/[&<>\"']/g, s => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[s])); }
function renderMarkdown(md = "") {
  let html = escapeHtml(md);
  html = html.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${escapeHtml(code)}</code></pre>`)
             .replace(/^######\s?(.*)$/gm, '<h6>$1</h6>')
             .replace(/^#####\s?(.*)$/gm, '<h5>$1</h5>')
             .replace(/^####\s?(.*)$/gm, '<h4>$1</h4>')
             .replace(/^###\s?(.*)$/gm, '<h3>$1</h3>')
             .replace(/^##\s?(.*)$/gm, '<h2>$1</h2>')
             .replace(/^#\s?(.*)$/gm, '<h1>$1</h1>')
             .replace(/^(?:- |\* )(.*)(?:\n(?:- |\* ).*)*/gm, (block) => {
                const items = block.split(/\n/).map(l => l.replace(/^(?:- |\* )/, "").trim());
                return `<ul>${items.map(i => `<li>${i}</li>`).join("")}</ul>`;
             })
             .replace(/^(?:\d+\. )(.*)(?:\n(?:\d+\. ).*)*/gm, (block) => {
                const items = block.split(/\n/).map(l => l.replace(/^\d+\. /, "").trim());
                return `<ol>${items.map(i => `<li>${i}</li>`).join("")}</ol>`;
             })
             .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
             .replace(/\*(.+?)\*/g, '<em>$1</em>')
             .replace(/`([^`]+?)`/g, '<code>$1</code>')
             .replace(/$begin:math:display$([^$end:math:display$]+)\]$begin:math:text$([^)]+)$end:math:text$/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  html = html.replace(/\n{2,}/g, '</p><p>');
  return `<p>${html}</p>`;
}

// ------- 空态渲染（Empty State）-------
function emptyBlock(kind = "summary") {
  // kind: "summary" | "cleaned" | "unsupported"
  const map = {
    summary: { icon: "📝", title: "暂无摘要", hint: "点击上方「提取并摘要」生成本页摘要" },
    cleaned: { icon: "📄", title: "暂无可读正文", hint: "点击上方「提取并摘要」提取整理后的正文" },
    unsupported: { icon: "🚫", title: "此页面不支持抓取", hint: "请切换到普通网页后再试" }
  };
  const { icon, title, hint } = map[kind] || map.summary;
  return `
    <div class="empty">
      <div class="icon">${icon}</div>
      <div class="title">${title}</div>
      <div class="hint">${hint}</div>
    </div>
  `;
}
function renderEmpty(kind = "both") {
  const sumEl = $("summary");
  const cleEl = $("cleaned");
  if (kind === "unsupported") {
    if (sumEl) sumEl.innerHTML = emptyBlock("unsupported");
    if (cleEl) cleEl.innerHTML = emptyBlock("unsupported");
    return;
  }
  if (sumEl) sumEl.innerHTML = emptyBlock("summary");
  if (cleEl) cleEl.innerHTML = emptyBlock("cleaned");
}

// ------- 进度条/按钮加载态/骨架屏 -------
function showProgress(show=true){
  const p = $("progress");
  if (!p) return;
  p.classList.toggle("hidden", !show);
}
function setButtonLoading(loading=true){
  const btn = $("btn-run");
  if (!btn) return;
  btn.classList.toggle("loading", loading);
  btn.disabled = !!loading;
  btn.textContent = loading ? "处理中…" : "提取并摘要";
}
function renderSkeletonLines(n=6){
  const lines = Array.from({length:n}, (_,i) => `<div class="skl" style="width:${80 - (i%3)*15}%"></div>`).join("");
  return `<div>${lines}</div>`;
}

// ------- 按“当前标签页 URL”缓存 -------
const CACHE_PREFIX = 'render_cache_v2:'; // 提升版本号，避免旧策略干扰

async function saveRenderCache(url, payload){
  if (!url) return;
  try { await S.set({ [CACHE_PREFIX + url]: payload }); } catch(e) { /* noop */ }
}
async function loadRenderCache(url){
  if (!url) return null;
  try { const d = await S.get([CACHE_PREFIX + url]); return d[CACHE_PREFIX + url]; } catch(e) { return null; }
}
async function clearCacheForUrl(url){
  if (!url) return;
  try { await S.remove([CACHE_PREFIX + url]); } catch(e) { /* noop */ }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}
async function getActiveTabUrl(){
  const tab = await getActiveTab();
  return tab?.url || null;
}

function renderToDom(summary, cleaned){
  const sumEl = $("summary");
  const cleEl = $("cleaned");
  if (sumEl) sumEl.innerHTML = summary ? renderMarkdown(summary) : emptyBlock("summary");
  if (cleEl) cleEl.innerHTML = cleaned ? renderMarkdown(cleaned) : emptyBlock("cleaned");
}

/** 严格按“当前活动标签页 URL”恢复；没有就显示空态 */
async function restoreForCurrentTab(){
  const url = await getActiveTabUrl();
  if (!url || url.startsWith("chrome://") || url.startsWith("edge://") || url.startsWith("chrome-extension://")) {
    renderEmpty("unsupported"); // 内置页不支持
    return;
  }
  const c = await loadRenderCache(url);
  if (c && (c.summary || c.cleaned)) {
    renderToDom(c.summary, c.cleaned);
  } else {
    renderEmpty(); // 正常空态
  }
}

// 事件：严格跟随“当前活动标签页”
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') restoreForCurrentTab(); });
window.addEventListener('focus', restoreForCurrentTab);
try { chrome.tabs.onActivated.addListener(restoreForCurrentTab); } catch {}
try {
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    // 1) 标签页开始加载（刷新/导航）就清空该 URL 的缓存
    if (changeInfo.status === 'loading' || changeInfo.url) {
      const url = changeInfo.url || tab?.url || (await chrome.tabs.get(tabId))?.url;
      if (url) await clearCacheForUrl(url);
      // 如果这个 tab 正是当前活动 tab，则同步显示空态
      const active = (await getActiveTab())?.id === tabId;
      if (active) renderEmpty();
    }
    // 2) 加载完成后，恢复（若之前生成过）
    if (changeInfo.status === 'complete') {
      const active = (await getActiveTab())?.id === tabId;
      if (active) restoreForCurrentTab();
    }
  });
} catch {}
try { chrome.windows.onFocusChanged.addListener(() => restoreForCurrentTab()); } catch {}
try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' || area === 'local') {
      if (Object.keys(changes).some(k => k.startsWith(CACHE_PREFIX))) {
        restoreForCurrentTab();
      }
    }
  });
} catch {}

// ------- 配置/注入/抓取 -------
async function ensureConfigured() {
  const data = await chrome.storage.sync.get(["apiKey"]);
  const ok = !!data.apiKey;
  const ob = $("onboarding");
  if (ob) ob.classList.toggle("hidden", ok);
  return ok;
}
async function injectIfNeeded(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: "PING_EXTRACTOR" });
    if (ping?.ok) return;
  } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["utils_extract.js"] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch (e) { console.warn("脚本注入失败", e); }
}
async function getPageRaw() {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error("未找到活动标签页（可能当前是 Chrome 内页或扩展页）");
  if (!tab?.url || tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("chrome-extension://")) {
    throw new Error("当前页面不支持内容注入，请切换到普通网页再试");
  }
  await injectIfNeeded(tab.id);
  const res = await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_RAW" });
  if (!res?.ok) throw new Error(res?.error || "抓取失败");
  return res.payload; // { title, text, url, pageLang }
}

// ------- 运行提取与摘要 -------
let running = false;
async function run() {
  if (running) return;
  running = true;
  showProgress(true);
  setButtonLoading(true);

  // 骨架屏占位
  const sumEl = $("summary");
  const cleEl = $("cleaned");
  if (sumEl) sumEl.innerHTML = renderSkeletonLines(5);
  if (cleEl) cleEl.innerHTML = renderSkeletonLines(10);

  try {
    if (!(await ensureConfigured())) { openOptions(); throw new Error("请先在设置页保存 API Key"); }
    const { title, text, url, pageLang } = await getPageRaw();

    const resp = await chrome.runtime.sendMessage({
      type: "AI_SUMMARIZE_REQUEST",
      payload: { url, rawText: text, title, pageLang }
    });
    if (!resp?.ok) throw new Error(resp?.error || "AI 处理失败");

    const { cleanedMarkdown, summary } = resp.data;
    renderToDom(summary, cleanedMarkdown);

    // 严格按“当前页面 URL”保存缓存
    await saveRenderCache(url, { summary, cleaned: cleanedMarkdown, ts: Date.now() });
  } catch (e) {
    console.error(e);
    alert("运行失败：\n" + (e?.message || String(e)));
    // 按当前标签页尝试恢复（若之前有）
    await restoreForCurrentTab();
  } finally {
    showProgress(false);
    setButtonLoading(false);
    running = false;
  }
}

// ------- 打开设置页（独立 options 页面）-------
function openOptions() {
  chrome.runtime.openOptionsPage();
  // 新策略：侧栏内容跟随当前活动标签页；打开设置页（扩展页）后，侧栏显示空态属于预期
}

// ------- 事件绑定 -------
function bind(id, handler) {
  const el = $(id);
  if (!el) return;
  el.addEventListener("click", handler);
}
onReady.then(() => {
  bind("btn-run", run);
  bind("btn-open-settings", openOptions);
  bind("go-settings", openOptions);

  ensureConfigured().catch(console.error);
  // 初始严格按“当前标签页 URL”恢复（无则空态）
  restoreForCurrentTab().catch(console.error);
  console.info("Sidepanel ready ✅ (per-tab cache + empty states)");
});