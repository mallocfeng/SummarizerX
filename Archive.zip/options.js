// 选项页：专门用于保存/测试配置
const $ = (id) => document.getElementById(id);
const onReady = new Promise((r) => (document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", r) : r()));

function setStatus(text) { $("status").textContent = text; }
function setMeta({ baseURL, model_extract, model_summarize, lang, extract_mode }) {
  document.getElementById("meta").textContent =
    `当前配置：extract=${model_extract}，summary=${model_summarize}，base=${baseURL}，lang=${lang || "auto"}，mode=${extract_mode || "fast"}`;
}

async function loadSettings() {
  const data = await chrome.storage.sync.get(["apiKey","baseURL","model_extract","model_summarize","lang","extract_mode"]);
  document.getElementById("apiKey").value = data.apiKey || "";
  document.getElementById("baseURL").value = data.baseURL || "https://api.openai.com/v1";
  document.getElementById("model_extract").value = data.model_extract || "gpt-4o-mini";
  document.getElementById("model_summarize").value = data.model_summarize || "gpt-4o-mini";
  document.getElementById("lang").value = (data.lang ?? "");
  document.getElementById("extract_mode").value = data.extract_mode || "fast";
  setMeta({
    baseURL: document.getElementById("baseURL").value,
    model_extract: document.getElementById("model_extract").value,
    model_summarize: document.getElementById("model_summarize").value,
    lang: document.getElementById("lang").value,
    extract_mode: document.getElementById("extract_mode").value
  });
}

async function saveSettings() {
  const payload = {
    apiKey: document.getElementById("apiKey").value.trim(),
    baseURL: document.getElementById("baseURL").value.trim(),
    model_extract: document.getElementById("model_extract").value.trim(),
    model_summarize: document.getElementById("model_summarize").value.trim(),
    lang: document.getElementById("lang").value,
    extract_mode: document.getElementById("extract_mode").value
  };
  await chrome.storage.sync.set(payload);
  setStatus("已保存设置 ✅");
  setMeta(payload);
}

async function testApiKey() {
  try {
    const key = $("apiKey").value.trim();
    const base = $("baseURL").value.trim() || "https://api.openai.com/v1";
    if (!key) throw new Error("请先输入 API Key");
    setStatus("⏳ 正在测试 API Key...");
    const res = await fetch(`${base.replace(/\/$/, "")}/models`, { headers: { Authorization: `Bearer ${key}` }});
    if (!res.ok) throw new Error(`无效: ${res.status} ${await res.text()}`);
    setStatus("✅ API Key 有效");
  } catch (e) {
    console.error(e);
    setStatus("❌ 测试失败：" + (e?.message || String(e)));
  }
}

async function showModelInfo() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: "GET_MODEL_INFO" });
    if (!resp?.ok) throw new Error(resp?.error || "无法获取模型信息");
    setMeta(resp.data);
    setStatus("ℹ️ 已读取后台当前配置的模型");
  } catch (e) { console.error(e); setStatus("❌ 读取失败：" + (e?.message || String(e))); }
}

function toggleApiKeyVisibility() {
  const input = $("apiKey");
  input.type = input.type === "password" ? "text" : "password";
}

function backToSidepanel() {
  // 尝试聚焦到最后一个聚焦窗口，并打开侧栏（如果用户点击扩展图标）
  chrome.windows.getLastFocused(() => {});
  alert("设置已完成，可回到侧栏使用“提取并摘要”。");
}

function bind(id, handler) {
  const el = $(id);
  if (el) el.addEventListener("click", handler);
}

onReady.then(() => {
  bind("btn-save", saveSettings);
  bind("btn-test", testApiKey);
  bind("btn-model-info", showModelInfo);
  bind("toggleKey", toggleApiKeyVisibility);
  bind("btn-back-sidepanel", backToSidepanel);
  loadSettings().catch(console.error);
  console.info("Options v1.4.0 ready ✅");
});
